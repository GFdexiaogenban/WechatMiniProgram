package utils.mysql;


import redis.clients.jedis.Jedis;

import java.sql.*;
import java.util.Set;

public class OpenidThread extends Thread {
    // JDBC 驱动名及数据库 URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/wechat?useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8";

    // 数据库的用户名与密码，需要根据自己的设置
    static final String USER = "admin";
    static final String PASS = "4thefuture";
    Connection conn = null;
    Statement stmt = null;
    Jedis jedis=null;
    public OpenidThread() throws Exception {
        // 注册 JDBC 驱动器
        Class.forName(JDBC_DRIVER);
        // 打开一个连接
        conn = DriverManager.getConnection(DB_URL,USER,PASS);
        // 执行 SQL 查询
        stmt = conn.createStatement();
        jedis = new Jedis("localhost");
    }

    public void run() {
        while (!this.isInterrupted()) {// 线程未中断执行循环
            try {
                Thread.sleep(1000); //每隔1000ms执行一次
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

//			 ------------------ 开始执行 ---------------------------
//            System.out.println("_____TIME:" + System.currentTimeMillis());

            Set<String> new_openids= jedis.smembers("new_openid");


            String sql="insert into openid (openid) values(?)";
            PreparedStatement pst = null;//用来执行SQL语句查询，对sql语句进行预编译处理

            try {
                conn.setAutoCommit(false);// 关闭事务
                pst = conn.prepareStatement(sql);
            } catch (SQLException e2) {
                e2.printStackTrace();
            }

            for(String temp:new_openids){
                //System.out.println(temp);

                try {
                    assert pst != null;
                    pst.setString(1, temp);
                    pst.addBatch();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            try {
                assert pst != null;
                pst.executeBatch();//执行给定的SQL语句，该语句可能返回多个结果
                conn.commit();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            jedis.del("new_openid");
        }
    }
}