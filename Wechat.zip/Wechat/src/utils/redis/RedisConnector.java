package utils.redis;

import redis.clients.jedis.Jedis;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class RedisConnector {
    public static boolean isFirstLogin(String openid) {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");
        // 如果 Redis 服务设置来密码，需要下面这行，没有就不需要
        // jedis.auth("123456");
        //System.out.println("连接成功");
        //查看服务是否运行
        //System.out.println("服务正在运行: "+jedis.ping());


        //如果redis中不存在该openid
        if(!jedis.sismember("openid",openid)){
            jedis.sadd("openid",openid);
            jedis.sadd("new_openid",openid);
            return true;
        }
        return false;
    }

    public static boolean addPerson(String name,String id,String phone,String a_name,String a_place){
        Jedis jedis = new Jedis("localhost");


        jedis.rpush("p_name",Objects.requireNonNullElse(name, "null"));
        jedis.rpush("p_cardID",Objects.requireNonNullElse(id, "null"));
        jedis.rpush("p_phone", Objects.requireNonNullElse(phone, "null"));
        jedis.rpush("p_a_name",Objects.requireNonNullElse(a_name, "null"));
        jedis.rpush("p_a_place",Objects.requireNonNullElse(a_place, "null"));
        Date date = new Date();
        jedis.rpush("p_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date));
        return true;
    }

    public static boolean addCarriedPerson(String name,String id,String phone,String relation,String p_cardID){
        Jedis jedis = new Jedis("localhost");
        jedis.rpush("c_name", Objects.requireNonNullElse(name, "null"));
        jedis.rpush("c_cardID",Objects.requireNonNullElse(id, "null"));
        jedis.rpush("c_phone",Objects.requireNonNullElse(phone, "null"));
        jedis.rpush("c_relation",Objects.requireNonNullElse(relation, "null"));
        jedis.rpush("c_p_cardID",Objects.requireNonNullElse(p_cardID, "null"));
        return true;
    }


}
