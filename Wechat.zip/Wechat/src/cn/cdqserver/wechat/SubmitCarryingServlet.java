package cn.cdqserver.wechat;

import cn.cdqserver.wechat.beans.AppInfo;
import cn.cdqserver.wechat.beans.CarriedPerson;
import com.sun.jna.platform.win32.OaIdl;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import utils.redis.RedisConnector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "SubmitCarryingServlet")
public class SubmitCarryingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        // 设置响应头允许ajax跨域访问
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        AppInfo appInfo=new AppInfo();

        CarriedPerson temp;


        String request_id=request.getParameter("id");

        JSONArray jsonArray= JSONArray.fromObject(request.getParameter("carrying"));
        //获得jsonArray的第一个元素
        int num=jsonArray.size();

        for(int i=0;i<num;i++){
            Object o=jsonArray.get(i);
            JSONObject jsonObject=JSONObject.fromObject(o);
            temp=(CarriedPerson)JSONObject.toBean(jsonObject, CarriedPerson.class);
            if(temp.getName()==null) {
                break;
            }


            //测试temp
            //System.out.println("temp:"+temp.getId()+"\n"+temp.getName()+"\n");

            RedisConnector.addCarriedPerson(temp.getName(), temp.getID(), temp.getTelephone(),temp.getRelation(),request_id);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
