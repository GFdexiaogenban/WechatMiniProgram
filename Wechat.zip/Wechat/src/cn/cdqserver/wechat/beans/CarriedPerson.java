package cn.cdqserver.wechat.beans;

public class CarriedPerson extends PersonBase {
    String p_cardID;
    String relation;


    public String getP_cardID() {
        return p_cardID;
    }

    public void setP_cardID(String p_cardID) {
        this.p_cardID = p_cardID;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public CarriedPerson(){
        super();
        p_cardID=null;
        relation=null;
    }
}
