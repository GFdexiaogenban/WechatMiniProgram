package cn.cdqserver.wechat.beans;

public class AppInfo {
    private final String APPID="wx099ecc49db428314";

    private final String APPSecret="fe50c28928e743a03b758b978b70755a";

    public String getAPPID() {
        return APPID;
    }

    public String getAPPSecret() {
        return APPSecret;
    }
}
