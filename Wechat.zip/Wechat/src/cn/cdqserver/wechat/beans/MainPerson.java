package cn.cdqserver.wechat.beans;

import com.sun.tools.javac.Main;

public class MainPerson extends PersonBase {

    String a_place;
    String a_name;
    String time;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getA_place() {
        return a_place;
    }

    public void setA_place(String a_place) {
        this.a_place = a_place;
    }

    public String getA_name() {
        return a_name;
    }

    public void setA_name(String a_name) {
        this.a_name = a_name;
    }
    public MainPerson(){
        super();
        time=null;
        a_name=null;
        a_place=null;
    }
}
