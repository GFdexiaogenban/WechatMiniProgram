package cn.cdqserver.wechat.listener;

import utils.mysql.OpenidThread;
import utils.mysql.PersonThread;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener()
public class PersonListener implements ServletContextListener{

    private PersonThread personThread;

    public void contextDestroyed(ServletContextEvent e) {
        if (personThread != null && personThread.isInterrupted()) {
            personThread.interrupt();
        }
    }

    public void contextInitialized(ServletContextEvent e) {
        String str = null;
        if (str == null && personThread == null) {
            try {
                personThread = new PersonThread();
                personThread.start(); // servlet 上下文初始化时启动 socket
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        }
    }

}