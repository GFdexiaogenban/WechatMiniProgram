package cn.cdqserver.wechat.listener;
import utils.mysql.CarriedPersonThread;
import utils.mysql.OpenidThread;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener()
public class CarriedPersonListener implements ServletContextListener{

    private CarriedPersonThread carriedPersonThread;

    public void contextDestroyed(ServletContextEvent e) {
        if (carriedPersonThread != null && carriedPersonThread.isInterrupted()) {
            carriedPersonThread.interrupt();
        }
    }

    public void contextInitialized(ServletContextEvent e) {
        String str = null;
        if (str == null && carriedPersonThread == null) {
            try {
                carriedPersonThread = new CarriedPersonThread();
                carriedPersonThread.start(); // servlet 上下文初始化时启动 socket
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        }
    }

}