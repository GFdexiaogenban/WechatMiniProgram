package cn.cdqserver.wechat;

import cn.cdqserver.wechat.beans.AppInfo;
import utils.WechatUtil;
import utils.redis.RedisConnector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.util.Map;


public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        // 设置响应头允许ajax跨域访问
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        //小程序相关信息
        AppInfo appInfo=new AppInfo();

        //获取小程序用户发送的code
        String code=request.getParameter("code");
        //调用code2Session获取用户openid、session_key
        Map<String,Object> info=WechatUtil.getWxUserOpenid(code,appInfo.getAPPID(),appInfo.getAPPSecret());

        //将用户openid以及session_key通过JSON格式发送到用户
        Writer out = response.getWriter();
        out.write(info.toString());

        //检查该用户是否第一次登录,如果是则将用户的openid存入redis
        RedisConnector.isFirstLogin(info.get("openid").toString());

        out.flush();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
