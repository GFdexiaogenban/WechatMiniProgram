package cn.cdqserver.wechat;

import cn.cdqserver.wechat.beans.AppInfo;
import cn.cdqserver.wechat.beans.MainPerson;
import utils.redis.RedisConnector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "SubmitInfoServlet")
public class SubmitInfoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        // 设置响应头允许ajax跨域访问
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        AppInfo appInfo=new AppInfo();

        MainPerson person=new MainPerson();
        /****    小程序二维码的结构    ****/
        /**** wx099ecc49db428314~活动名称示范~举办方名称示范~17700000000~重庆市北碚区西南大学25教~2020-11-24 16:24:34~2020-11-24 16:24:34   ***/
        //    小程序标识+活动名称+举办方名称+举办方联系方式+活动地点+活动开始时间+活动结束时间

        //以后是传扫码结果的id
        String AppID=request.getParameter("appid");

        if(AppID.compareTo(appInfo.getAPPID())!=0) return;

        person.setName(request.getParameter("name"));
        person.setID(request.getParameter("ID"));
        person.setTelephone(request.getParameter("telephone"));
        String active_name=request.getParameter("topic");
        String active_place=request.getParameter("message");


        System.out.println(person.getName());
        RedisConnector.addPerson(person.getName(),person.getID(), person.getTelephone(), active_name,active_place);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
